import java.io.File;
import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class InspeccionandoReserva {
	private Grafo g;
	
	
	public InspeccionandoReserva(String nombreArchivo) {
		try {
			Scanner sc= new Scanner(new File(nombreArchivo));
			int cantidadNodo=sc.nextInt();
			int cantidadArista=sc.nextInt();
			g= new Grafo(cantidadNodo,Integer.MAX_VALUE);
			for (int i = 0; i < cantidadNodo; i++) {
				g.addNodos(new Nodo(i));
			}
			
			for (int i = 0; i <cantidadArista; i++) {
				g.addAristas(new Arista(new Nodo(sc.nextInt()),new Nodo(sc.nextInt()),1));
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public int obtenerCantidadCaminos(Nodo inicial,Nodo fin) {
		Queue<Nodo> cola = new LinkedList<Nodo>();
		boolean []visitados= new boolean[g.cantidadNodos()];
		
		for (boolean b : visitados) {
			b=false;
		}
		
		visitados[inicial.getNumero()]=true;
		cola.add(inicial);
		inicial.setCaminosEntrantes(1);
		
		while(!cola.isEmpty()){
			Nodo n1=cola.poll();
			//visitados[n1.getNumero()]=true;
			for(int i=0;i<g.cantidadNodos();i++) {
				if(!visitados[i] && g.getAristas(n1,new Nodo(i))) {
					g.getNodos().get(i).setAdyacentesentrantes(1);
					g.getNodos().get(i).setCaminosEntrantes(n1.getCaminosEntrantes());
					cola.add(g.getNodos().get(i));
					if(g.getNodos().get(i).getAdyacentesentrantes()==g.getCantEntrantes(new Nodo(i)))
						visitados[i]=true;
				}					
					
			}
			
		}
		
		return g.getNodos().get(fin.getNumero()).getCaminosEntrantes();		
	}
	
}
