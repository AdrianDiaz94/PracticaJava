
public class MainTest {

	public static void main(String[] args) {
	InspeccionandoReserva i= new InspeccionandoReserva("archivo.txt");
	System.out.println(i.obtenerCantidadCaminos(new Nodo(0), new Nodo(9)));
	
	}

}
